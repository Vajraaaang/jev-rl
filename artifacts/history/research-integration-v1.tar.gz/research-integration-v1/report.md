# Incident recovery benchmark

Offline heuristic experiment; hosted Jev effectiveness is untested.

Simulator probes alone determine sustained recovery. The advisor never grades its own success.

| Policy | Recovery | Actions | Downtime ticks | Tool cost units |
|---|---:|---:|---:|---:|
| checklist | 77.5% | 13.71 | 12.37 | 4.16 |
| random | 13.9% | 6.09 | 7.11 | 1.28 |
| greedy | 45.0% | 14.98 | 19.32 | 0.12 |
| rl_without_jev | 16.7% | 1.83 | 1.67 | 0.31 |
| rl_with_jev | 63.9% | 7.00 | 8.86 | 1.84 |
| rl_with_corrupted_advisor | 64.0% | 7.04 | 8.92 | 1.84 |

## Paired uncertainty

crossed paired bootstrap of training seeds and incident families. Synthetic population only; few training seeds make seed uncertainty unstable.

- rl_with_jev minus rl_without_jev: recovery difference 0.472, 95% interval [0.384, 0.571].
- rl_with_jev minus checklist: recovery difference -0.136, 95% interval [-0.212, -0.067].
- rl_with_jev minus rl_with_corrupted_advisor: recovery difference -0.001, 95% interval [-0.008, 0.000].

## Limits

- Small synthetic sandbox; recovery results do not establish production safety or transfer.
- Only local controllers learn. Diagnostic sensor weights and rubric remain fixed.
- Independent cause scores are multilabel scores, not calibrated probabilities.
- Three seeds by default provide limited information about training variability.
- Impossible incidents remain in overall recovery denominators; subgroup metrics report them separately.
- Costs are simulated tool units and provider acquisition estimates, not total infrastructure or output-token billing.
- No hyperparameter search or validation-set checkpoint selection was performed.
- Advisor corruption is a probability-complement stress test, not a realistic model of all diagnostic failures.

Diagnostic accuracy, per-suite, per-seed, impossible-incident, cost and provenance details are in report.json.
